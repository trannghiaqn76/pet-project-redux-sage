    
import {combineReducers} from 'redux'
import allTestReducers from '../Areas/Test/reducers';
//IndexImportHygen
const allReducers = combineReducers({
    allTestReducers,
    //IndexUsingHygen
})

export default allReducers;
