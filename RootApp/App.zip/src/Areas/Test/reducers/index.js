import {combineReducers} from 'redux'
import isResultReducer from "./isResultReducer"
import testReducer from "./testReducer"
import test123Reducer from "./test123Reducer"
import test123Reducer from "./test123Reducer"
import test123Reducer from "./test123Reducer"
//IndexImportHygen
const allTestReducers = combineReducers({
    isResultReducer,
    testReducer,
    test123Reducer,
    test123Reducer,
    test123Reducer,
    //IndexUsingHygen
})

export default allTestReducers;