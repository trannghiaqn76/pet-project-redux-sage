import TestComponent from "./Test"
import Test123Component from "./Test123"
//IndexImportHygen
export {
    TestComponent,
    Test123Component,
    //IndexUsingHygen
};